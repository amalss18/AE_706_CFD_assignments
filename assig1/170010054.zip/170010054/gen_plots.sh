mkdir data
mkdir plots
g++ 170010054.cpp
./a.out 0
python 170010054.py
